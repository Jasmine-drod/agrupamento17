PASTA assets:
- Substitua 'logo-placeholder.png' pelo logotipo oficial da AEA (mesmo nome de ficheiro).
- Substitua photo1.jpg, photo2.jpg, ... com as fotos reais do agrupamento.
