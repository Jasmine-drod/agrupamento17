// Pequeno JS para interações básicas (placeholder)
console.log('Site Agrupamento 17 carregado');